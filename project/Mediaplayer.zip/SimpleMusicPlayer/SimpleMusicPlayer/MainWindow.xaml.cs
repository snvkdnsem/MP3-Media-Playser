﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Win32;

namespace SimpleMusicPlayer
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    

    public partial class MainWindow : Window
    {
        ListBoxItem currentTrack;
        ListBoxItem PreviousTrack;
        DispatcherTimer timer;
        bool isDragging;

        public MainWindow()
        {
            InitializeComponent();

            currentTrack = null;
            PreviousTrack = null;

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += new EventHandler(timer_Tick);

            isDragging = false;



            
            
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (!isDragging)
            {
                musicSlider.Value = media.Position.TotalSeconds;
            }
        }

        private void Previous(object sender, RoutedEventArgs e)
        {

        }

        private void Pause(object sender, RoutedEventArgs e)
        {
            media.Pause();
        }

        private void Play(object sender, RoutedEventArgs e)
        {
            PlayTrack();
        }

        private void Stop(object sender, RoutedEventArgs e)
        {
            media.Stop();
        }

        private void Next(object sender, RoutedEventArgs e)
        {
            MoveToNextTrack();
        }

        private void Repeat(object sender, RoutedEventArgs e)
        {
            MoveToPrecedentTrack();
        }

        private void VolumeOnOff(object sender, RoutedEventArgs e)
        {
            if (media.Volume != 0)
            {
                volumeControl.Value = 0;
            }
            else
            {
                volumeControl.Value = 0.5;
            }
        }

        // 파일추가 코딩
        private void FileAdd(object sender, RoutedEventArgs e)
        {
            //using Micosoft.Win32; 가 필요하다
            OpenFileDialog myDialog = new OpenFileDialog();
            myDialog.Filter = "Image Files(*.BMP;*.JPG;*.GIF)|*.BMP;*.JPG;*.GIF|All files (*.*)|*.*";
            myDialog.CheckFileExists = true;
            myDialog.Multiselect = true;

            if (myDialog.ShowDialog() == true)
            {

                foreach(string file in myDialog.FileNames)
                {
                    ListBoxItem musicList = new ListBoxItem();
                    musicList.Content = System.IO.Path.GetFileNameWithoutExtension(file);
                    musicList.Tag = file;
                    lstFiles.Items.Add(musicList);
                }
            }
        }

        private void PlayTrack()
        {
            if (lstFiles.SelectedItem != currentTrack)
            {
                if (currentTrack != null)
                {
                    PreviousTrack = currentTrack;
                }
                currentTrack = (ListBoxItem)lstFiles.SelectedItem;
                media.Source = new Uri(currentTrack.Tag.ToString());
                musicSlider.Value = 0; 
                media.Play();
            }
            else
            {
                media.Play();
            }

            TagLib.File file = TagLib.File.Create(currentTrack.Tag.ToString());

            string Album = file.Tag.Album;
            string Title = file.Tag.Title;
            string[] Singer = file.Tag.Artists;
            TimeSpan RunTime = file.Properties.Duration;


            album.Content = Album;
            title.Content = Title;
            singer.Content = Singer[0];
            runTime.Content = RunTime.Minutes + ":" + RunTime.Seconds;

            ////////////////////앨범 아트//////////////////////

            TagLib.IPicture album_cover = file.Tag.Pictures[0];
            System.IO.MemoryStream memoryStream = new System.IO.MemoryStream(album_cover.Data.Data);
            BitmapImage cover = new BitmapImage();
            cover.BeginInit();
            cover.StreamSource = memoryStream;
            cover.EndInit();

            albumart.Source = cover;

        }

        private void PlayMusic(object sender, RoutedEventArgs e)
        {
            if (media.NaturalDuration.HasTimeSpan)
            {
                TimeSpan ts = media.NaturalDuration.TimeSpan;
                musicSlider.Maximum = ts.TotalSeconds;
                musicSlider.SmallChange = 1;
            }
            timer.Start();
        }

        private void EndMusic(object sender, RoutedEventArgs e)
        {
            musicSlider.Value = 0;
            MoveToNextTrack();
        }

        private void MoveToNextTrack()
        {
            if (lstFiles.Items.IndexOf(currentTrack) < lstFiles.Items.Count - 1)
            {
                lstFiles.SelectedIndex = lstFiles.Items.IndexOf(currentTrack) + 1;
                PlayTrack();
                return;
            }
            else if (lstFiles.Items.IndexOf(currentTrack) == lstFiles.Items.Count - 1)
            {
                lstFiles.SelectedIndex = 0;
                PlayTrack();
                return;
            }
        }

        private void MoveToPrecedentTrack()
        {
            if (lstFiles.Items.IndexOf(currentTrack) > 0)
            {
                lstFiles.SelectedIndex = lstFiles.Items.IndexOf(currentTrack) - 1;
                PlayTrack();
            }
            else if (lstFiles.Items.IndexOf(currentTrack) == 0)
            {
                lstFiles.SelectedIndex = lstFiles.Items.Count - 1;
                PlayTrack();
            }

        }
    }
}
