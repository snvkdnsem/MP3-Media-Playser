﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SimpleMusicPlayer
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            TagLib.File file = TagLib.File.Create(@"ProjectMusic\엠씨더맥스 - 어디에도.mp3");
                       
            string Album = file.Tag.Album;
            string Title = file.Tag.Title;
            string[] Singer = file.Tag.AlbumArtists;
            TimeSpan RunTime = file.Properties.Duration;
            
            album.Content = Album;
            title.Content = Title;
            singer.Content = Singer[0];
            runTime.Content = RunTime.Minutes + ":" + RunTime.Seconds;

            ////////////////////앨범 아트//////////////////////

            TagLib.IPicture album_cover = file.Tag.Pictures[0];
            System.IO.MemoryStream memoryStream = new System.IO.MemoryStream(album_cover.Data.Data);
            BitmapImage cover = new BitmapImage();
            cover.BeginInit();
            cover.StreamSource = memoryStream;
            cover.EndInit();

            albumart.Source = cover;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }
               
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {

        }
    }
}