﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace SimpleMusicPlayer
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            TagLib.File file = TagLib.File.Create(@"ProjectMusic\엠씨더맥스 - 어디에도.mp3");


            string Album = file.Tag.Album;
            string Title = file.Tag.Title;
            string[] Singer = file.Tag.AlbumArtists;
            TimeSpan RunTime = file.Properties.Duration;


            album.Content = Album;
            title.Content = Title;
            singer.Content = Singer[0];
            runTime.Content = RunTime.Minutes + ":" + RunTime.Seconds;

            ////////////////////앨범 아트//////////////////////

            TagLib.IPicture album_cover = file.Tag.Pictures[0];
            System.IO.MemoryStream memoryStream = new System.IO.MemoryStream(album_cover.Data.Data);
            BitmapImage cover = new BitmapImage();
            cover.BeginInit();
            cover.StreamSource = memoryStream;
            cover.EndInit();

            albumart.Source = cover;
        }

        private void Previous(object sender, RoutedEventArgs e)
        {

        }

        private void Pause(object sender, RoutedEventArgs e)
        {
            media.Pause();
        }

        private void Play(object sender, RoutedEventArgs e)
        {
            media.Play();
        }

        private void Stop(object sender, RoutedEventArgs e)
        {
            media.Stop();
        }

        private void Next(object sender, RoutedEventArgs e)
        {

        }

        private void Repeat(object sender, RoutedEventArgs e)
        {

        }

        private void VolumeOnOff(object sender, RoutedEventArgs e)
        {
            if (media.Volume != 0)
            {
                volumeControl.Value = 0;
            }
            else
            {
                volumeControl.Value = 0.5;
            }
        }

        private void VolumeControl(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            media.Volume = (double)volumeControl.Value;
        }

        // 파일추가 코딩
        private void FileAdd(object sender, RoutedEventArgs e)
        {
            //using Micosoft.Win32; 가 필요하다
            OpenFileDialog myDialog = new OpenFileDialog();
            myDialog.Filter = "Image Files(*.BMP;*.JPG;*.GIF)|*.BMP;*.JPG;*.GIF|All files (*.*)|*.*";
            myDialog.CheckFileExists = true;
            myDialog.Multiselect = true;

            if (myDialog.ShowDialog() == true)
            {
                lstFiles.Items.Clear();
                foreach(string file in myDialog.FileNames)
                {
                    lstFiles.Items.Add(file);
                }
            }
        }
    }
}
